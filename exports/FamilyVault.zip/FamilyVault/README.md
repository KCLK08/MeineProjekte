# Family Vault

Privater digitaler Familienordner — **nur mobile** (iOS/Android), vollständig offline.

Ehemals Teil des Monorepos `KCLK08/MeineProjekte` (`apps/familydata`). Dieses Repository ist die eigenständige Home-Base für Family Vault.

## Start

```bash
npm install
npm start
```

Development Build / Release-APK (nicht Expo Go) für den Vault.

## Sicherheitshinweise

- Nur Dummy-/Testdaten zum Ausprobieren
- Keine echten Dokumente, Ausweise oder Familieninfos committen
- Lokale DB und Dateien liegen außerhalb von Git (siehe `.gitignore`)
- Vault mit Biometrie / Gerätecode (Einstellungen → Sicherheit)

## Navigation

1. Familie
2. Dokumente
3. Einstellungen (Zahnrad oben)

## Dokumentation

- `docs/FAMILY_SYNC_ARCHITECTURE_DECISIONS.md` – Family Sync Decision Log
- `FAMILY_SYNC_PHASE1_ANALYSIS.md` – Ist-Analyse für Family Sync
- `SECURITY_IMPLEMENTATION.md`, `DEVICE_TRANSFER_*.md` – Sicherheit & Geräteübertragung

## APK CI

Workflow: `.github/workflows/build-apk.yml` → Artifact + Release-Tag `familyvault-apk-latest`.
