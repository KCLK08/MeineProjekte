# Family Vault – Import in neues Repo

1. Dieses Zip entpacken.
2. Inhalt des Ordners `FamilyVault/` in dein neues Repo-Root kopieren
   (`https://github.com/KCLK08/FamilyVault`).
3. Committen und pushen:

```bash
cd FamilyVault   # entpackter Ordner bzw. geklontes Repo
git init         # falls noch kein Git
git add .
git commit -m "Initial import: Family Vault standalone"
git branch -M main
git remote add origin https://github.com/KCLK08/FamilyVault.git
git push -u origin main
```

Falls das Repo schon existiert und geklont ist: Dateien hineinlegen, `git add .`, commit, push.
