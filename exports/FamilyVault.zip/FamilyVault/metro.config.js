const { getDefaultConfig } = require('expo/metro-config');
const { withNativeWind } = require('nativewind/metro');
const path = require('path');

const projectRoot = __dirname;
const monorepoRoot = path.resolve(projectRoot, '../..');

const config = getDefaultConfig(projectRoot);
config.watchFolders = [monorepoRoot];
config.resolver.nodeModulesPaths = [
  path.resolve(projectRoot, 'node_modules'),
  path.resolve(monorepoRoot, 'node_modules'),
];
config.resolver.disableHierarchicalLookup = true;
// Vendored pdf.js sources shipped as .txt so they are not executed as modules.
config.resolver.assetExts = Array.from(new Set([...(config.resolver.assetExts || []), 'txt']));

module.exports = withNativeWind(config, { input: './global.css' });
